import axios, { AxiosResponse } from 'axios';

// Definir la URL base de la API
const baseURL = 'https://mystoreapi.com';

// Función para obtener todos los productos
async function getAllProducts(): Promise<any> {
  try {
    const response: AxiosResponse<any> = await axios.get(`${baseURL}/Catalog/products`);

    // Devolver los datos de la respuesta
    return response.data;
  } catch (error) {
    console.error('Error al obtener productos:', error);
    return [];
  }
}

// Ejemplo de uso
(async () => {
  // Obtener todos los productos
  const products = await getAllProducts();
  console.log('Productos:', products);
})();